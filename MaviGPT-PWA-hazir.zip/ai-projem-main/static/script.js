(() => {
  "use strict";

  /* -------------------------
     PWA
  ------------------------- */
  let deferredInstallPrompt = null;

  function createInstallButton() {
    if (document.getElementById("mavigpt-install-button")) return;

    const button = document.createElement("button");
    button.id = "mavigpt-install-button";
    button.type = "button";
    button.className = "mavigpt-install-button";
    button.innerHTML = "📱 <span>MaviGPT'yi Yükle</span>";
    button.setAttribute("aria-label", "MaviGPT'yi telefona uygulama olarak yükle");

    button.addEventListener("click", async () => {
      if (deferredInstallPrompt) {
        deferredInstallPrompt.prompt();
        const result = await deferredInstallPrompt.userChoice;
        if (result && result.outcome === "accepted") {
          button.style.display = "none";
        }
        deferredInstallPrompt = null;
        return;
      }

      alert(
        "MaviGPT zaten kurulu olabilir veya tarayıcı şu anda uygulama yükleme ekranını göstermiyor. " +
        "Chrome'da sayfayı HTTPS üzerinden açıp tekrar deneyin."
      );
    });

    document.body.appendChild(button);
  }

  window.addEventListener("beforeinstallprompt", (event) => {
    event.preventDefault();
    deferredInstallPrompt = event;

    const button = document.getElementById("mavigpt-install-button");
    if (button) button.classList.add("show");
  });

  window.addEventListener("appinstalled", () => {
    deferredInstallPrompt = null;
    const button = document.getElementById("mavigpt-install-button");
    if (button) button.style.display = "none";
  });

  /* Service worker */
  if ("serviceWorker" in navigator && window.isSecureContext) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("/service-worker.js", { scope: "/" })
        .catch((error) => console.warn("MaviGPT service worker:", error));
    });
  }

  /* -------------------------
     Splash screen
  ------------------------- */
  window.addEventListener("load", () => {
    setTimeout(() => {
      const splash = document.getElementById("splash-screen");
      if (!splash) return;

      splash.style.opacity = "0";
      setTimeout(() => {
        splash.style.display = "none";
      }, 600);
    }, 1200);
  });

  /* Create after DOM exists */
  document.addEventListener("DOMContentLoaded", createInstallButton);
})();
